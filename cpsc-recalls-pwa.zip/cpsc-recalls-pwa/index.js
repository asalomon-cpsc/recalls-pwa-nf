import { RecallFormatter } from '/assets/global.js';

document.addEventListener('DOMContentLoaded', () => {
  // Fetch featured recalls and create cards
  fetch('data/latest.json')
    .then(response => response.json())
    .then(data => {
      createFeaturedCards(data.recalls);
    })
    .catch(error => {
      console.error('Error fetching featured recalls:', error);
    });
});

const createFeaturedCards = (recalls) => {
  const featuredList = document.getElementById('featured');
  recalls.forEach(recall => {
    const li = document.createElement('li');
    li.className = 'card recall-link';
    li.innerHTML = `
      <div class="card-content">
        <img src="${recall.images[0].url}" alt="${recall.title}" class="card-image">
        <div class="card-text">
          <h2>${recall.title}</h2>
          <p>Recall Date: ${new Date(recall.recallDate).toLocaleDateString()}</p>
          <p>Recall Number: ${RecallFormatter.formatRecallNumber(recall.recallNumber)}</p>
        </div>
      </div>
    `;

    li.addEventListener('click', (e) => {
      e.preventDefault();
      const recallDetails = {
        title: recall.title,
        images: recall.images,
        products: recall.products,
        inconjuctions: recall.inconjuctions,
        recallNumber: RecallFormatter.formatRecallNumber(recall.recallNumber),
        recallDate: new Date(recall.recallDate).toLocaleDateString(),
        description: recall.description,
        hazard: recall.hazards[0]?.name || 'Not specified',
        remedy: recall.remedies[0]?.name || 'Not specified',
        units: recall.products[0]?.numberOfUnits || 'Not specified',
        incidents: recall.injuries[0]?.name || 'None reported',
        soldAt: recall.retailers[0]?.name || 'Not specified',
        manufacturers: recall.manufacturers.map(m => m.name).join(', ') || 'Not specified',
        manufacturedIn: recall.manufacturerCountries.map(m => m.country).join(', ') || 'Not specified',
        consumerContact: recall.consumerContact
      };
      const event = new CustomEvent('showRecallDetails', { detail: recallDetails });
      document.dispatchEvent(event);
    });

    featuredList.appendChild(li);
  });
};
