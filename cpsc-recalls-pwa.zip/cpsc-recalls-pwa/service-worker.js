const CACHE_NAME = 'cpsc-recalls-v2';
const ENV = 'dev';
const urlsToCache = [
  '/',
  '/index.html',
  '/assets/'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        if(ENV !== 'dev'){
          console.log('Caching assets' + ENV);
          cache.addAll(urlsToCache)
        }
})
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        
        return fetch(event.request).then(
          (response) => {
            // Check if we received a valid response
            if(!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Only cache files from the root and assets directory
            if (ENV!== 'dev' && event.request.url.match(/^https?:\/\/[^\/]+\/($|assets\/)/)) {
              // Clone the response
              const responseToCache = response.clone();

              caches.open(CACHE_NAME)
                .then((cache) => {
                  cache.put(event.request, responseToCache);
                });
            } 

            return response;
          }
        );
      })
  );
});
