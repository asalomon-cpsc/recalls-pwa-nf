import {
    RecallFormatter
} from './global.js';


// Function to detect mobile devices and their platform
const getMobilePlatform = () => {
    const userAgent = navigator.userAgent || navigator.vendor || window.opera;
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        return 'iOS';
    }
    if (/android/i.test(userAgent)) {
        return 'Android';
    }
    return null;
};

// Function to check if the app is installed
const isAppInstalled = () => {
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
};

const showInstallPrompt = () => {
    const platform = getMobilePlatform();
    if (!platform) return; // Exit if not a mobile device

    const dialog = document.createElement('dialog');
    dialog.className = 'install-dialog';

    let content;
    if (platform === 'iOS') {
        content = `
            <h3>Install This App</h3>
            <p>Install this app on your iPhone for a better experience:</p>
            <ol>
                <li>Tap the share button <span class="share-icon ios-share-icon"></span> at the bottom of your browser</li>
                <li>Scroll down and tap "Add to Home Screen"</li>
            </ol>
        `;
    } else if (platform === 'Android') {
        content = `
            <h3>Install This App</h3>
            <p>Install this app on your Android device for a better experience:</p>
            <ol>
                <li>Tap the menu button <span class="share-icon android-menu-icon"></span> in your browser</li>
                <li>Tap "Add to Home screen"</li>
            </ol>
        `;
    }

    dialog.innerHTML = `
        <div class="install-dialog-content">
            ${content}
            <button id="closeInstallDialog">Close</button>
        </div>
    `;
    document.body.appendChild(dialog);

    setTimeout(() => {
        dialog.showModal();
    }, 0);

    document.getElementById('closeInstallDialog').addEventListener('click', () => {
        dialog.close();
        localStorage.setItem('installPromptShown', 'true');
    });
};

const handleAPIResponse = (response) => {
    if (response.recalls && Array.isArray(response.recalls)) {
        const recallCount = response.recalls.length;
        showSuccessMessage(`Retrieved ${recallCount} recall${recallCount !== 1 ? 's' : ''}`);
        displayRecallResults(response.recalls);
    } else {
        showErrorMessage('Unexpected API response format');
    }
};

const showErrorMessage = (message) => {
    if (statusMessage) {
        statusMessage.textContent = `Error: ${message}`;
        statusMessage.className = 'status-message error';
    }
};

const showSuccessMessage = (message) => {
    if (statusMessage) {
        statusMessage.textContent = message;
        statusMessage.className = 'status-message success';
    }
};

const displayRecallResults = (recalls) => {
    const resultsContainer = document.getElementById('recallResults');
    resultsContainer.innerHTML = ''; // Clear previous results

    recalls.forEach(recall => {
        const recallElement = document.createElement('div');
        recallElement.classList.add('recall-item');
        recallElement.innerHTML = `
        <h3>${recall.title}</h3>
        <p>Date: ${recall.recallDate}</p>
        <p>${recall.description}</p>
        <p>Recall Number: ${RecallFormatter.formatRecallNumber(recall.recallNumber)}</p>
      `;
        resultsContainer.appendChild(recallElement);
    });
};

class BottomSheet {
  constructor(element, options = {}) {
    this.element = element;
    this.options = Object.assign({
      dragThreshold: 0.25,
      onOpen: () => {},
      onClose: () => {}
    }, options);

    this.init();
  }

  init() {
    this.closeButton = this.element.querySelector('.close-button');
    this.closeButton.addEventListener('click', () => this.close());

    this.setupDragging();
  }

  open() {
    this.element.classList.add('active');
    this.options.onOpen();
  }

  close() {
    this.element.classList.remove('active');
    this.options.onClose();
  }

  setupDragging() {
    let startY, startHeight;

    const onTouchStart = (e) => {
      startY = e.touches[0].clientY;
      startHeight = this.element.offsetHeight;
      this.element.style.transition = 'none';
    };

    const onTouchMove = (e) => {
      const deltaY = startY - e.touches[0].clientY;
      const newHeight = startHeight + deltaY;
      this.element.style.height = `${newHeight}px`;
    };

    const onTouchEnd = () => {
      this.element.style.transition = 'height 0.3s ease-out';
      if (this.element.offsetHeight < window.innerHeight * this.options.dragThreshold) {
        this.close();
      } else {
        this.element.style.height = '';
      }
    };

    this.element.addEventListener('touchstart', onTouchStart);
    this.element.addEventListener('touchmove', onTouchMove);
    this.element.addEventListener('touchend', onTouchEnd);
  }
}

document.addEventListener('DOMContentLoaded', () => {
    const drawer = document.querySelector('.drawer');
    const infoButton = document.getElementById('infoButton');
    const bottomSheet = document.getElementById('bottomSheet');
    const closeButton = document.getElementById('closeButton');
    const applyBtn = document.getElementById('applyBtn');
    const resetBtn = document.getElementById('resetBtn');
    const progressCircle = document.getElementById('progressCircle');
    const form = document.getElementById('recallSearchForm');
    const statusMessage = document.getElementById('statusMessage');
    const searchBtn = document.getElementById('searchBtn');
    const homeBtn = document.getElementById('homeBtn');
    const helpBtn = document.getElementById('helpBtn');
    const backBtn = document.getElementById('backBtn');
    const recallBottomSheet = new BottomSheet(document.getElementById('recallBottomSheet'));
    const recallDetails = document.getElementById('recallDetails');
    const closeRecallSheet = document.getElementById('closeRecallSheet');
    let startY, startHeight, currentHeight;

    // Bottom navigation handling
    if (homeBtn) {
        homeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = '/';
        });
    }

    if (helpBtn) {
        helpBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = '/help';
        });
    }

    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.history.back();
        });
    }

    // Check if elements exist before adding event listeners
    if (searchBtn && drawer) {
        console.log('searchBtn and drawer exist');
        searchBtn.addEventListener('click', () => {
            drawer.classList.toggle('open');
        });

        document.addEventListener('click', (event) => {
            if (!drawer.contains(event.target) && !searchBtn.contains(event.target)) {
                drawer.classList.remove('open');
            }
        });
    }else{
        console.log('searchBtn or drawer do not exist');
    }

    if (infoButton && bottomSheet) {
        infoButton.addEventListener('click', () => {
            bottomSheet.classList.toggle('active');
        });
    }

    if (closeButton && bottomSheet) {
        closeButton.addEventListener('click', (event) => {
            event.stopPropagation();
            bottomSheet.classList.remove('active');
        });

        bottomSheet.addEventListener('click', (event) => {
            if (event.target === bottomSheet) {
                bottomSheet.classList.remove('active');
            }
        });
    }

    if (applyBtn && form) {
        applyBtn.addEventListener('click', async (event) => {
            event.preventDefault();

            if (!isFormValid()) {
                showPopup('Please fill in at least one field before searching.');
                return;
            }

            if (progressCircle) progressCircle.style.display = 'inline-block';
            applyBtn.disabled = true;
            if (statusMessage) {
                statusMessage.textContent = '';
                statusMessage.className = 'status-message';
            }

            try {
                const formData = new FormData(form);
                const searchParams = new URLSearchParams(formData);
                
                // Redirect to the results page with form data as URL parameters
                window.location.href = `result-list?${searchParams.toString()}`;
            } catch (error) {
                console.error('Error preparing search:', error);
                showErrorMessage(error.message);
                if (progressCircle) progressCircle.style.display = 'none';
                applyBtn.disabled = false;
            }
        });
    }

    if (resetBtn && form) {
        resetBtn.addEventListener('click', () => {
            form.reset();
        });
    }

    // Form validation function
    const isFormValid = () => {
        const inputs = form.querySelectorAll('input[type="text"]');
        return Array.from(inputs).some(input => input.value.trim() !== '');
    };

    // Popup message function
    const showPopup = (message) => {
        const popup = document.createElement('div');
        popup.className = 'popup';
        popup.innerHTML = `
          <div class="popup-content">
            <p>${message}</p>
            <button id="closePopup">OK</button>
          </div>
        `;
        document.body.appendChild(popup);

        const closePopup = document.getElementById('closePopup');
        closePopup.addEventListener('click', () => {
            document.body.removeChild(popup);
        });
    };

    // Install prompt for mobile devices
    //if (!isAppInstalled() && !localStorage.getItem('installPromptShown')) {
   //     setTimeout(showInstallPrompt, 2000);
   // }
    showInstallPrompt();

    // Listen for the custom showRecallDetails event
    document.addEventListener('showRecallDetails', (event) => {
        const details = event.detail;
        console.log('details', details);
        showRecallDetails(details);
    });

    const showRecallDetails = (details) => {
        recallDetails.innerHTML = `
          <div class="recall-header">
            <h2>${details.title}</h2>
            <div class="recall-pills">
              <span class="recall-pill">Recall Number: ${details.recallNumber}</span>
              <span class="recall-pill">Recall Date: ${details.recallDate}</span>
            </div>
          </div>
          ${details.images && details.images.length > 0 ? `
        <div class="recall-image-container">
          <img src="${details.images[0].url}" alt="${details.title}" class="recall-image">
        </div>
      ` : ''}
          <div class="recall-card">
            <h3><span class="material-icons">category</span>Products</h3>
            <p>${details.products.map(product => product.name).join(', ')}</p>
          </div>
          <div class="recall-card recall-description-card">
            <h3><span class="material-icons">description</span>Description</h3>
            <p>${details.description}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">warning</span>Hazard</h3>
            <p>${details.hazard}</p>
          </div>
          <div class="recall-card recall-contact-card">
            <h3><span class="material-icons">contact_support</span>Consumer Contact</h3>
            <p>${details.consumerContact}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">build</span>Remedy</h3>
            <p>${details.remedy}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">inventory_2</span>Units</h3>
            <p>${details.units}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">report_problem</span>Incidents</h3>
            <p>${details.incidents}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">store</span>Sold At</h3>
            <p>${details.soldAt}</p>
          </div>
          ${details.inconjunctions && details.inconjunctions.length > 0 ? `
            <div class="recall-card">
              <h3><span class="material-icons">link</span>In Conjunction With</h3>
              <p>${details.inconjunctions.map(item => item.name || 'Unnamed').join(', ')}</p>
            </div>
          ` : ''}
          <div class="recall-card">
            <h3><span class="material-icons">business</span>Manufacturers</h3>
            <p>${details.manufacturers}</p>
          </div>
          <div class="recall-card">
            <h3><span class="material-icons">public</span>Manufactured In</h3>
            <p>${details.manufacturedIn}</p>
          </div>
          
        `;
        recallBottomSheet.open();
    };

    const chatButton = document.getElementById('chatButton');
    const chatBottomSheet = new BottomSheet(document.getElementById('chatBottomSheet'));
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');

    chatButton.addEventListener('click', () => chatBottomSheet.open());

    sendButton.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    function sendMessage() {
        const message = chatInput.value.trim();
        if (message) {
            addMessage('user', message);
            chatInput.value = '';
            setTimeout(() => {
                const response = processMessage(message);
                addMessage('bot', response);
            }, 1000);
        }
    }

    function addMessage(sender, text) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('chat-message', sender);
        messageElement.textContent = text;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function processMessage(message) {
        // Simplified message processing logic
        if (message.toLowerCase().includes('recall')) {
            return "I can help you with recall information. Please provide a product name or recall number for more details.";
        } else if (message.toLowerCase().includes('contact')) {
            return "For general inquiries, please contact our customer support at support@example.com or call 1-800-123-4567.";
        } else {
            return "I'm sorry, I didn't understand that. Can you please rephrase your question?";
        }
    }
});

// Service Worker registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then((registration) => {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            }, (err) => {
                console.log('ServiceWorker registration failed: ', err);
            });
    });
}
