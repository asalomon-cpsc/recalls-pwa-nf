class RecallFormatter {
  static formatRecallNumber(recallNumber) {
    if (typeof recallNumber !== 'string' || recallNumber.length !== 5) {
      return recallNumber; // Return original if not a 5-digit string
    }
    return `${recallNumber.slice(0, 2)}-${recallNumber.slice(2)}`;
  }
}

// If using ES6 modules
export { RecallFormatter };

// If not using ES6 modules, you can make it globally available like this:
// window.RecallFormatter = RecallFormatter;

